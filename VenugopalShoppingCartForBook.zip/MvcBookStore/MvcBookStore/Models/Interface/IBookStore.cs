﻿using MvcBookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;


namespace MvcMusicStore.Models.Interface
{
    public class BookSearchService : IBookstoreService
    {
        //public Task<IEnumerable<Book>> GetBooksAsync(string searchString)
        //{
        //    string search = "lookforme";
        //    List<Book> myList = new List<Book>();
        //   // Task<IEnumerable<Book>> result = myList.Single(s => s.Author.Name == searchString.ToString()|| s.Title == searchString.ToString());
        //    Task<IEnumerable<Book>> result = myList.FindAll(s => s.Author.Name == searchString.ToString() || s.Title == searchString.ToString()) as IEnumerable<Book>();
        //    dinosaurs.FindAll(EndsWithSaurus);
        //    return result;

        //}
       public async Task<IEnumerable<Book>> GetBooksAsync(string searchString)
        {
            //int hours;
            // . . .
            // Return statement specifies an integer result.
            // return hours;
          ShoppingCart  myList = new ShoppingCart();
            return(myList.GetCartItemsSearch(searchString)as IEnumerable<Book>);
            //return intResult;
        }
      //  int intResult = await TaskOfTResult_MethodAsync();

       
    }
    public interface IBookstoreService
    {
        Task<IEnumerable<Book>> GetBooksAsync(string searchString);
    }

    

}
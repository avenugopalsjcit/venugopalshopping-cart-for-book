﻿using MvcBookStore.Models;
using MvcBookStore.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;


namespace MvcMusicStore.Controllers
{
    public class SendMailController : Controller
    {
       // private object storeDB;
        BookStoreEntities storeDB = new BookStoreEntities();
        // GET: SendMail
        public ActionResult Index(string ipalue)
        {
           

            Order order = new Order();
            var cart = ShoppingCart.GetCart(this.HttpContext);

           
            // Remove from cart
            bool itemCount = cart.RemoveFromCart(ipalue);

            // Display the confirmation message
           


            return View("SendMail");
        }

        // GET: SendMail/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SendMail/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SendMail/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: SendMail/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SendMail/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: SendMail/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SendMail/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}

﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using MvcBookStore.Models;
using MvcMusicStore.Models.Interface;
using System.Net.Mail;

using System.Threading.Tasks;
using MvcBookStore.ViewModels;

namespace MvcBookStore.Controllers
{
    public class HomeController : Controller
    {
        int index;
        //
        // GET: /Home/

        BookStoreEntities storeDB = new BookStoreEntities();

       
        public ActionResult SearchIndex(string ipvalue)
        {
           
              Session["name"] = "1";
            TempData["value"] = ipvalue;
           
            Session["Textvalue"] = ipvalue;
           
            return RedirectToAction("Index", "Home");
        }

      

        public ActionResult IndexSearchBind(List<Book> arg)
        {
            return View(arg);
        }

       

        public async Task<ActionResult> Index()
        {

            if (Session["name"] != "1")
            {

                var albums = GetTopSellingBooks(5);
                return View(albums);


            }

            else
            {
                // Get most popular albums
                BookSearchService Booksearch = new BookSearchService();
                List<Book> albumsa = await Booksearch.GetBooksAsync(TempData["value"].ToString()) as List<Book>;
                Session["name"] = "0";
                return View(albumsa);
            }
        }

        private List<Book> GetTopSellingBooks(int count)
        {
            // Group the order details by album and return
            // the albums with the highest count

            return storeDB.Books
                .OrderByDescending(a => a.OrderDetails.Count())
                .Take(count)
                .ToList();
        }
    }
}